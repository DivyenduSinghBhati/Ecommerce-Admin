'use client';

import { PuffLoader } from 'react-spinners';

export const Loader = () => {
    return <PuffLoader color='#3498db' size={20} />;
};